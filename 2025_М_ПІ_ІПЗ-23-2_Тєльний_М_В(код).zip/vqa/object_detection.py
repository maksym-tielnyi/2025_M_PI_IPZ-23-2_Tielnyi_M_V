from ultralytics import YOLO

model = YOLO('yolov8n.pt')

def detect_objects(image_path, confidence_threshold=0.3):
    results = model(image_path)[0]

    detected_objects = set()
    for res in results.boxes:
        conf = res.conf.item()
        cls = int(res.cls.item())
        if conf >= confidence_threshold:
            detected_objects.add(model.names[cls])
    
    return list(detected_objects)
    