import torch
import torch.nn as nn
from transformers import CLIPProcessor, CLIPModel, T5Tokenizer, T5ForConditionalGeneration
from PIL import Image

class VQAMultimodalKG:
    def __init__(self, vision_model='openai/clip-vit-base-patch32', text_model='t5-base'):
        self.clip_processor = CLIPProcessor.from_pretrained(vision_model)
        self.clip_model = CLIPModel.from_pretrained(vision_model)

        self.tokenizer = T5Tokenizer.from_pretrained(text_model, legacy=False)
        self.text_model = T5ForConditionalGeneration.from_pretrained(text_model)

        self.visual_proj = nn.Linear(self.clip_model.visual_projection.out_features, 
                                     self.text_model.config.d_model)

    def generate_answer(self, question, image_path, kg_context, max_length=50):
        image = Image.open(image_path).convert('RGB')

        inputs = self.clip_processor(images=image, return_tensors="pt")
        visual_embeds = self.clip_model.get_image_features(**inputs)

        visual_embeds_proj = self.visual_proj(visual_embeds).unsqueeze(1)

        input_text = f"question: {question} context: {kg_context}"

        input_ids = self.tokenizer(input_text, return_tensors='pt').input_ids

        outputs = self.text_model.generate(
            inputs_embeds=torch.cat((visual_embeds_proj, self.text_model.encoder.embed_tokens(input_ids)), dim=1),
            max_length=max_length,
            num_beams=4,
            early_stopping=True
        )

        answer = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return answer
