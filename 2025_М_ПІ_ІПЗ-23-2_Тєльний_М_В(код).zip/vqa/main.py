from vqa_multimodal import VQAMultimodalKG
from kg_retrieval import get_kg_triples
from object_detection import detect_objects

question = "From which country is this person?"
image_path = "leonardo.jpg"

print("Question: ", question)
print("Image path: ", image_path)

entity_labels = detect_objects(image_path)
print("Detected objects:", entity_labels)

kg_context = get_kg_triples(entity_labels, question)

model = VQAMultimodalKG()
answer = model.generate_answer(question, image_path, kg_context)

print(f"Answer: {answer}")