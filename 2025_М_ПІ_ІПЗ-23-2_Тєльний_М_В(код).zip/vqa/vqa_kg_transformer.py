import torch
import torch.nn as nn
from transformers import BertModel, BertTokenizer

class VQAKGTransformer(nn.Module):
    def __init__(self, bert_model='bert-base-uncased', kg_embedding_dim=384, hidden_dim=768, num_answers=1000):
        super().__init__()
        self.tokenizer = BertTokenizer.from_pretrained(bert_model)
        self.bert = BertModel.from_pretrained(bert_model)
        
        self.kg_proj = nn.Linear(kg_embedding_dim, hidden_dim)

        self.classifier = nn.Sequential(
            nn.Linear(hidden_dim * 2, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, num_answers)
        )

    def forward(self, question, kg_embedding):
        inputs = self.tokenizer(question, return_tensors='pt', padding=True, truncation=True)

        outputs = self.bert(**inputs)
        text_embedding = outputs.pooler_output

        kg_emb_proj = self.kg_proj(kg_embedding)

        combined_embedding = torch.cat([text_embedding, kg_emb_proj.unsqueeze(0)], dim=1)

        logits = self.classifier(combined_embedding)
        return logits
