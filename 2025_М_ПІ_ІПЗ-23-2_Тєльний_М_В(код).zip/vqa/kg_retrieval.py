from SPARQLWrapper import SPARQLWrapper, JSON
import time
import re

def fetch_entity(label):
    sparql = SPARQLWrapper("https://query.wikidata.org/sparql")
    query = f'''
    SELECT DISTINCT ?entity WHERE {{
      SERVICE wikibase:mwapi {{
        bd:serviceParam wikibase:api "EntitySearch";
                        wikibase:endpoint "www.wikidata.org";
                        mwapi:search "{label}";
                        mwapi:language "en".
        ?entity wikibase:apiOutputItem mwapi:item.
      }}
    }} LIMIT 1
    '''
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()
    bindings = results["results"]["bindings"]
    return bindings[0]['entity']['value'].split('/')[-1] if bindings else None

def fetch_all_triples(entity_id, label, top_k=50):
    sparql = SPARQLWrapper("https://query.wikidata.org/sparql")
    query = f'''
    SELECT ?propertyLabel ?valueLabel WHERE {{
      wd:{entity_id} ?direct_property ?value.
      ?property wikibase:directClaim ?direct_property.
      SERVICE wikibase:label {{ bd:serviceParam wikibase:language "en". }}
    }} LIMIT {top_k}
    '''
    sparql.setQuery(query)
    sparql.setReturnFormat(JSON)
    results = sparql.query().convert()

    triples = []
    for result in results["results"]["bindings"]:
        prop = result["propertyLabel"]["value"]
        val = result["valueLabel"]["value"]
        triples.append((prop.lower(), val.lower(), f"{label} {prop} {val}"))

    return triples

def extract_keywords(question):
    stop_words = {"what", "is", "the", "of", "on", "image", "in", "a", "an"}
    words = re.findall(r'\w+', question.lower())
    return [word for word in words if word not in stop_words]

def filter_relevant_triples(triples, keywords):
    relevant = []
    for prop, val, full_triple in triples:
        if any(kw in prop or kw in val for kw in keywords):
            relevant.append(full_triple)
    return relevant

def get_kg_triples(labels, question, top_k=10):
    all_triples = []
    keywords = extract_keywords(question)

    for label in labels:
        entity_id = fetch_entity(label)
        if entity_id:
            all_entity_triples = fetch_all_triples(entity_id, label, top_k=top_k)
            relevant_triples = filter_relevant_triples(all_entity_triples, keywords)

            if relevant_triples:
                all_triples.extend(relevant_triples[:top_k])
            else:
                all_triples.extend([t[2] for t in all_entity_triples[:top_k]])
        else:
            print(f"No entity found for '{label}'")
        time.sleep(1)

    return "; ".join(all_triples)
